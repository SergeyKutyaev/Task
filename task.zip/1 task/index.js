const inputEl = document.querySelector("input");
const buttonEl = document.querySelector("button");
const timerEl = document.querySelector("span");

const createTimerAnimator = (time) => {
  const timerId = setInterval(() => {
    if (time >= 0) {
      const timeString = parsingValue(time);
      timerEl.innerText = timeString;
      time -= 1;
    } else {
      clearInterval(timerId);
    }
  }, 1000);
};

inputEl.addEventListener("input", () => {
  if (inputEl.value != "") {
    const reg = new RegExp(/\d+/);
    const match = inputEl.value.match(reg)[0];
    inputEl.value = match;
  }
});

function parsingValue(time) {
  const seconds = Math.trunc(time % 60);
  const minutes = Math.trunc((time / 60) % 60);
  const hours = Math.trunc(time / 3600);

  return `${hours <= 9 ? "0" + hours : hours} : ${
    minutes <= 9 ? "0" + minutes : minutes
  } : ${seconds <= 9 ? "0" + seconds : seconds}`;
}

buttonEl.addEventListener("click", () => {
  let time = Number(inputEl.value);
  createTimerAnimator(time);
});
